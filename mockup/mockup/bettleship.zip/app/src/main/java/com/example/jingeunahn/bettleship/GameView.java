package com.example.jingeunahn.bettleship;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
//view class
public class GameView extends View{

    private Bitmap battleship;
    private Bitmap big_airplane;
    private Bitmap big_submarine;
    private Bitmap little_airplane;
    private Bitmap little_submarine;
    private Bitmap medium_airplane;
    private Bitmap medium_submarine;
    private Bitmap water;

    /**
     *
     * @param context
     */
    public GameView(Context context) {
        super(context);
        //loading picture files using factory method
        battleship = BitmapFactory.decodeResource(getResources(),R.drawable.battleship);
        big_airplane = BitmapFactory.decodeResource(getResources(),R.drawable.big_airplane);
        big_submarine = BitmapFactory.decodeResource(getResources(),R.drawable.big_submarine);
        little_airplane = BitmapFactory.decodeResource(getResources(),R.drawable.little_airplane);
        little_submarine = BitmapFactory.decodeResource(getResources(),R.drawable.little_submarine);
        medium_airplane = BitmapFactory.decodeResource(getResources(),R.drawable.medium_airplane);
        medium_submarine = BitmapFactory.decodeResource(getResources(),R.drawable.medium_submarine);
        water = BitmapFactory.decodeResource(getResources(),R.drawable.water);
    }

    @Override
    public void onDraw(Canvas c) {
        //get valuables for width and height of creen
        int w = getWidth();
        int h = getHeight();
        //paint method
        Paint forbitmap = new Paint();
        c.drawColor(Color.WHITE);

        //sizes
        battleship = battleship.createScaledBitmap(battleship, (int)(w*0.45), (int)(h*0.23), true);
        big_submarine= big_submarine.createScaledBitmap(big_submarine, (int)(w*0.09), (int)(h*0.09), true);
        big_airplane = big_airplane.createScaledBitmap(big_airplane, (int)(w*0.09), (int)(h*0.09), true);
        little_airplane = little_airplane.createScaledBitmap(little_airplane, (int)(w*0.03), (int)(h*0.03), true);
        little_submarine = little_submarine.createScaledBitmap(little_submarine, (int)(w*0.03), (int)(h*0.03), true);
        medium_submarine = medium_submarine.createScaledBitmap(medium_submarine, (int)(w*0.07), (int)(h*0.07), true);
        medium_airplane = medium_airplane.createScaledBitmap(medium_airplane, (int)(w*0.07), (int)(h*0.07), true);
        water = water.createScaledBitmap(water, (int)(w*0.02),(int)(w*0.02),true);

        //positions
        for(int i = 0; i < w; i+=water.getWidth()) {
            c.drawBitmap(water, i, h*0.5f, forbitmap);
        }

        c.drawBitmap(battleship, w*0.25f, h*0.31f,forbitmap);
        c.drawBitmap(big_airplane,  w*0.6f, h*0.05f,forbitmap);
        c.drawBitmap(medium_airplane,  w*0.4f, h*0.15f,forbitmap);
        c.drawBitmap(little_airplane,  w*0.15f, h*0.1f,forbitmap);
        c.drawBitmap(big_submarine,  w*0.4f, h*0.6f,forbitmap);
        c.drawBitmap(medium_submarine,  w*0.6f, h*0.8f,forbitmap);
        c.drawBitmap(little_submarine,  w*0.2f, h*0.7f,forbitmap);
    }
}
