package com.example.jingeunahn.bettleship;

/**
 * Created by anjin on 11/24/2015.
 */
public abstract class Enemy extends Sprite {
    /**
     * enum class to put int values
     */
    public enum Size {
        BIG,
        MEDIUM,
        LITTLE
    }
}
